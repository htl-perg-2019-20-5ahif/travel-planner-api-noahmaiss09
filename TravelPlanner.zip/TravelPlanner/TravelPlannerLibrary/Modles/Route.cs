﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TravelPlannerLibrary.Modles
{
    public class Route
    {
        public string Depart { get; set; }
        public string DepartureTime { get; set; }
        public string Arrive { get; set; }
        public string ArrivalTime { get; set; }
    }
}
